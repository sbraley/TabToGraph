package com.ibm.i2.tab;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Properties;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;




public class ProcessTabular 
{
	private String csvName;
	private String ximpName;
	private String outputName;
    private boolean sendToGraph = false;

	
	private Document ximpDoc;
	private String delimFromXimp = "";
	
	Map<String, String> entityCollection;			// each entity is a collection of columns
	Collection<Map<String, String>> allEntities;	// a collection of all entities, to iterate 
	
	Map<String, String> linkCollection;				// each link is a collection of properties
	Collection<Map<String, String>> allLinks;		// a collection of all links, to iterate
	
	Map<String, String> entityIds;					// in ximp, entity types are represented as "Icon 1" etc.  Map this to
													// a defined GraphType attrib in the ximp, e.g. "Person"
	
	Map<String, String> entityIndexes;				// which columns in the csv 
	Collection<Map<String, Integer>> allEntityIndexes = new ArrayList<Map<String, Integer>>();

	StringBuffer accumulatedVertices;
		
	private static String GRAPH_TYPE = "GraphType"; 
	private static String VALUE = "Value";
	private static String TEXT = "Text";
	private static String ENTITY_ID = "EntityId";
	private static String ATTRIBUTE = "Attribute";
	private static String CLASS = "Class";
	private static String ENTITY = "Entity";
	private static String LINK = "Link";
	private static String COLUMN = "Column";
	private static String COLUMN_ID = "ColumnId";
	private static String FROM_ENTITY_ID = "FromEntityId";
	private static String TO_ENTITY_ID = "ToEntityId";
	private static String OBJECT_ID = "ObjectId";
	private static String TO_ID = "inV";
	private static String ITEM_ID = "id";
	private static String LABEL = "label";
	private static String OUT_EDGE = "outE";
	
    private CloseableHttpClient client = null;
    private String apiURL = null;
    private String userId = null;
    private String password = null;
    
    private int currentId;
	
	public static void main(String[] args)
    {
		/*
		 * pass in the path/name of the TabToGraph.properties file on the command line (or
		 * Eclipse args)
		 * e.g. -Dprops=/workspace/TabToGraph.properties
		 */
		ProcessTabular process = new ProcessTabular();
		System.out.println("processing . . .");
		try
		{
			process.execute();
		}
		catch (Exception e)
		{
			// catch
		}
        return;
    }

    private void execute() throws JSONException
    {
        initialize();
        parseXimp();
        tabLineByLine();
        createGraphsonT3();

    }

    private void initialize()
    {
        currentId = 1000;  // TODO create a thread-safe, random way to seed the ids
        
        accumulatedVertices = new StringBuffer();	// will hold all completed vertex-centric objects (with embedded edges)
        
    	allEntities = new ArrayList<Map<String, String>>();
    	allLinks = new ArrayList<Map<String, String>>();
    	entityIds = new HashMap<String, String>();
    	
    	String propsName = System.getProperty("props");
    	Properties tabProps = new Properties();
    	InputStream in;
		try 
		{
			in = new FileInputStream(propsName);
			tabProps.load(in);
		} 
		catch (FileNotFoundException e1) 
		{
			e1.printStackTrace();
			System.exit(-1);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}
    	
		csvName = tabProps.getProperty("csv");
    	ximpName = tabProps.getProperty("ximp");
    	outputName = tabProps.getProperty("output");
    	String send = tabProps.getProperty("send");
    	sendToGraph = Boolean.parseBoolean(send);	

   	    apiURL = tabProps.getProperty("apiURL");
        userId = tabProps.getProperty("userId");
        password = tabProps.getProperty("password");

    	    	if(  (csvName == null || csvName.equals("")) || (ximpName == null || ximpName.equals("")) || (outputName == null || outputName.equals("")) )
    	{
    		System.out.println("usage: java  -Dprops=<name of properties file> -jar ProcessTabular.jar");
    		System.exit(-1);
    	}

        client = HttpClients.createDefault();

    	
    	// open ximp
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    	DocumentBuilder db;
		try 
		{
			db = dbf.newDocumentBuilder();
			ximpDoc = db.parse(new File(ximpName));
		} 
		catch (ParserConfigurationException e) 
		{
			e.printStackTrace();
		} 
		catch (SAXException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
    }

    /*
     * go through the ximp file, which was created using the ANB import utility
     * get the delimiter for the csv, a map of entity types, and a map of link types
     */
    
    private void parseXimp()
    {
    	getDelimCharacter();
    	buildEntitiesMap();
    	buildLinksMap();
    }
    
    /*
     * a ximp file will have a delimiter e.g. comma or tab
     */
    private void getDelimCharacter()
    {
    	// <DelimitedColumns Delimiters="," IgnoreWhenPrecededBy="\" IgnoreWhenContainedBy="&quot;" />
    	NodeList delimList = ximpDoc.getElementsByTagName("DelimitedColumns");
    	for (int i=0; i<delimList.getLength(); i++) 
	    {
    		Element ele = (Element) delimList.item(i);
    		delimFromXimp = ele.getAttribute("Delimiters");
	    }
    }
    
	/*
	 * go through the ximp file and find each entity type
	 * create a map for each entity type, with its attributes
	 * add that map to a collection of all entity types
	 * also, map the ximp name for an entity (e.g. "Icon 1") to the GraphType attribute from the ximp
	 * 
	 */
    
    private void buildEntitiesMap()
    {
       	String attribName = "";
    	String attribValue = "";
    	boolean foundGraphType = false;
    	
    	ximpDoc.getDocumentElement().normalize();
    	
    	NodeList nodeList = ximpDoc.getElementsByTagName(ENTITY);
    	for (int i=0; i<nodeList.getLength(); i++) 
	    {
    		// for each entity type create a new Map and add it to the Collection of Maps
			Map<String, String> thisEntity = new TreeMap<String, String>();
    		Element thisEntityElement = (Element) nodeList.item(i);
    		String entityId = thisEntityElement.getAttribute(ENTITY_ID);  // this will be written lower down with the graphType e.g. Person=Icon 1
    		NodeList attrNodeList = thisEntityElement.getElementsByTagName(ATTRIBUTE);
    		for (int j=0; j<attrNodeList.getLength(); j++) 
    		{
    			Element thisAttrNode = (Element)attrNodeList.item(j);
    			NodeList theClassNodeList = thisAttrNode.getElementsByTagName(CLASS);
    			for(int k=0; k<theClassNodeList.getLength(); k++)
    			{
    				NodeList subClassNodeList = thisAttrNode.getElementsByTagName(TEXT);
    				for(int m=0; m<subClassNodeList.getLength(); m++)
    				{
    					Element textElement = (Element)subClassNodeList.item(m);
    					String value = textElement.getAttribute(VALUE);
    					// HACK ALERT, UGLY UGLY   There are two things called "Value" at the same level for this type only   					
    					attribName = value;
    					if(value.equals(GRAPH_TYPE))
    					{
    						foundGraphType = true;  // GraphType has to be added by hand in import utility, we must enforce it here
    						break;
    					}
    				}
    			}
	    	   
    			NodeList theValueNodeList = thisAttrNode.getElementsByTagName(VALUE);
    			for(int k=0; k<theValueNodeList.getLength(); k++)
    			{
    				Element textOrValueNode = (Element)theValueNodeList.item(k); 
    				NodeList textNodeList = textOrValueNode.getElementsByTagName(TEXT);
    				for(int m=0; m<textNodeList.getLength();)
    				{
    					Element textElement = (Element)textNodeList.item(m);
    					String value = textElement.getAttribute(VALUE);
    					attribValue = value;
    					// this means we found the entity type, so write to our entity id mappings here  (e.g. "Icon 1" == Person)
    					entityIds.put(entityId,  value);
    					break;
    				}
    				NodeList colNodeList = textOrValueNode.getElementsByTagName(COLUMN);
    				for(int m=0; m<colNodeList.getLength(); m++)
    				{
    					Element textElement = (Element)colNodeList.item(m);
    					String value = textElement.getAttribute(COLUMN_ID);
    					attribValue = value;
    				}
    			}
    			thisEntity.put(attribName, attribValue);
    		}
    		
			if(!foundGraphType)
			{
				// the ximp MUST contain an attribute called "GraphType" which indicates the entity type
				System.out.println("ximp file is missing an attribute called 'GraphType'; correct the ximp"
						+ "and run TabToGraph again.");
				System.exit(-1);
			}

        	allEntities.add(thisEntity);
	    }
    }
    
    
    /*
     * read the ximp and map all links, and their FROM and TO entity types
     */
    private void buildLinksMap()
    {
    	NodeList nodeListLinks = ximpDoc.getElementsByTagName(LINK);

	    for (int i=0; i<nodeListLinks.getLength(); i++) 
	    {
			Map<String, String> thisLink = new TreeMap<String, String>();
			Element thisLinkElement = (Element) nodeListLinks.item(i);
			String fromId = thisLinkElement.getAttribute(FROM_ENTITY_ID);
			String toId = thisLinkElement.getAttribute(TO_ENTITY_ID);
			
			thisLink.put(TO_ENTITY_ID, entityIds.get(toId));
			thisLink.put(FROM_ENTITY_ID, entityIds.get(fromId));
			
			allLinks.add(thisLink);
	    }
    }
    /*
		read the csv file line by line.  split using the delim in the import spec;
		create entities and links by looking up the column indexes for each attribute to be imported
		if it's an entity, translate the named type (e.g. "Icon 1") into the entity type (e.g. "Person")
	*/
    private void tabLineByLine() throws JSONException
    {
    	boolean firstLine = true;
    	
    	System.out.println("processing csv file ...");
    	
    	//TODO some error checking is needed to verify the csv has correct columns for ximp
    	try(BufferedReader br = new BufferedReader(new FileReader(csvName))) 
    	{
    	    for(String line; (line = br.readLine()) != null; ) 
    	    {
    	    	if(firstLine)
    	    	{
    	    		// get the column headings
        	    	firstLine = false;
        	    	mapHeaderToEntityMap(line);
        	    	continue;
    	    	}
    	    	
    	    	String[] thisLine = line.split(delimFromXimp);   
    	    	makeVerticesAndEdges(thisLine);
    	    }
    	}
    	catch(Exception ex)
    	{
    		System.out.println(ex.toString());
    	}

    	return;
    }
    
    
    void makeVerticesAndEdges(String[] thisLine) throws JSONException
    {
    	JSONObject newObject;
    	
    	Map<String, Integer> entityAndId = new HashMap<String, Integer>();
    	Map<String, JSONObject> typeAndObject = new HashMap<String, JSONObject>();
    	
    	Iterator<Map<String, Integer>> it = allEntityIndexes.iterator();
    	while(it.hasNext())
    	{
    		//for each entity type, get the values from the line for just that particular type
    		String thisType = "";
    		newObject = new JSONObject();
	    	
    		Map<String, Integer> thisEntity = (Map<String, Integer>) it.next();  // this will be e.g. "Person"
    		for(Map.Entry<String,Integer> entry : thisEntity.entrySet())
    		{
    			String key = entry.getKey();
    			int val = entry.getValue();   // this is the index of the column with the desired value
    			if(val > 0)
    			{
    				newObject.put(key, thisLine[val]);
    			}
    			else
    			{
    				// graph type is not part of the ximp, so will not be part of the object map,
    				// so we have a special case for it.
    				newObject.put(LABEL,  key);
    				thisType = key;
    			}
    		} 

			int uniqueId =  getUniqueId();       // UUID.randomUUID().toString();
			newObject.put(OBJECT_ID, uniqueId);
			newObject.put(ITEM_ID, uniqueId);
			
			
    		entityAndId.put(thisType, uniqueId);
    		typeAndObject.put(thisType, newObject);

    	}

    	
    	// iterate entityAndId
    	// for each from/to pair
    	// and create edges for vertices which are already created for this row
    	Iterator<Map<String, String>> itLinks = allLinks.iterator();
    	while(itLinks.hasNext())
    	{
    		// iterate through all link types
	    	Map<String, String> thisLinkType = itLinks.next();
	    	
	    	String fromType = (String)thisLinkType.get(FROM_ENTITY_ID);
	    	String toType = (String)thisLinkType.get(TO_ENTITY_ID);

    		JSONObject from = typeAndObject.get(fromType);
    		JSONObject to = typeAndObject.get(toType);
	    	String edgeLabel = fromType.substring(0, 3).toUpperCase() + toType.substring(0, 3).toUpperCase();
	    	int toId = to.getInt(ITEM_ID); 
	    	int uniqueId = getUniqueId();

	    	// this JSON looks crazy but it's the only thing that would correctly load the graph into Bluemix Graph Store
	    	JSONArray edgeProps = new JSONArray();

	    	JSONObject jsonProps = new JSONObject();
	    	jsonProps.put(ITEM_ID, uniqueId);
	    	jsonProps.put(TO_ID, toId);
	    	edgeProps.put(jsonProps);
	    	
	    	JSONObject jsonEdge = new JSONObject();
	    	jsonEdge.put(edgeLabel, edgeProps);
	    	
	    	JSONObject wholeEdge = new JSONObject();
	    	wholeEdge.put(edgeLabel, edgeProps);
	    	
	    	from.put(OUT_EDGE, wholeEdge);
    	}
    	
    	
    	//  iterate typeAndObject, write out to accumulatedVertices
    	
    	Iterator itAll = typeAndObject.entrySet().iterator();
    	while(itAll.hasNext())
    	{
    		@SuppressWarnings("rawtypes")
			Map.Entry thisObj = (Map.Entry)itAll.next();
            accumulatedVertices.append(thisObj.getValue());
        	accumulatedVertices.append("\n");
    	}
    }
    
    private int getUniqueId()
    {
    	// UUID.randomUUID().toString();
        // TODO make this assignment thread-safe
    	
    	
    	return currentId++;
    }
    
    private void createGraphsonT3()
    {
    	
    	System.out.println("outputting graphson ...");

    	writeToFile(accumulatedVertices.toString());
    	
    	if(sendToGraph)
    	{
    		doUpload();
    		countNodes();   // for test purposes only, take out when there is a count API for V and E
    	}
    	
    	System.out.println("... output complete.");
    }
    

    
    /*
     * writeToFile(): output the full created graphson to the filename indicated in the args
     */
    private void writeToFile(String graphson)
    {
    	try  
    	{
    		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputName), "utf-8"));
    		writer.write(graphson);
    		writer.close();
    	}
    	catch (Exception ex)
    	{
    		System.out.println("Error writing to file: " + ex.getMessage());
    	}
    }
    
    /*
     * mapHeaderToEntityMap():
     * String line: the header line from the csv file
     * 	for each entity type, create a map of indexes for values in the line
    	e.g. Person->Last_Name maps to column #2 in the csv
    	create array of column indexes from the csv, for each property for the entity
     */
    
    private void mapHeaderToEntityMap(String line)
    {
    	String[] headers;

    	headers = line.split(delimFromXimp);
    	
    	Iterator<Map<String, String>> it = allEntities.iterator();
    	while(it.hasNext())
    	{
    		Map<String, Integer> thisEntityIndexes = new TreeMap<String, Integer>();
    		Map<String, String> thisEntity = (Map<String, String>) it.next();  // this will be e.g. "Person"
    		for(Map.Entry<String,String> entry : thisEntity.entrySet())
    		{
    			// for each property in "Person"
    			String key = entry.getKey();
    			String val = entry.getValue();
    			// look up the val in the header array
    			int index = Arrays.asList(headers).indexOf(val);
    			if(index > 0)
    			{
    				thisEntityIndexes.put(key, index);      // note we are storing "key", not "val"
    														// attribs have an optional "alias" which can be different from column header name
    			}
    			else if(key.equals(GRAPH_TYPE))
    			{
    				// GraphType has to be special-cased because it's not a property of the file itself,
    				// it's a hand-coded attribute we added in ANB
    				thisEntityIndexes.put(val, -99);
    			}
    		}
    		// add this array of indexes to collection
    		allEntityIndexes.add(thisEntityIndexes);
    	}
    	return;
    }
    
    /*
     * printMap(): utility method to print the contents of a map
     * used for debugging only
     */
    
    public static void printMap(@SuppressWarnings("rawtypes") Map map) 
    {
        @SuppressWarnings("rawtypes")
		Iterator it = map.entrySet().iterator();
        while (it.hasNext()) 
        {
            @SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry)it.next();
            System.out.println(pair.getKey() + " = " + pair.getValue());
        }
    }


    private void countNodes()
    {
    	String basicAuth = null;
    	
        //String username = creds.getString("username");
        //String password = creds.getString("password");
        byte[] userpass = (userId + ":" + password).getBytes();
        byte[] encoding = Base64.encodeBase64(userpass);
        
        basicAuth = "Basic " + new String(encoding);    	
        HttpGet httpGet = new HttpGet(apiURL + "/vertices");
        httpGet.setHeader("Authorization", basicAuth);
        
        HttpResponse httpResponse;
		try {
			httpResponse = client.execute(httpGet);
	    	HttpEntity httpEntity = httpResponse.getEntity();
	    	String content = EntityUtils.toString(httpEntity);
	    	EntityUtils.consume(httpEntity);
	    	JSONObject jsonContent = new JSONObject(content);
	    	
	    	JSONArray vertices = jsonContent.getJSONArray("result");
	    	System.out.println("count of V: " + jsonContent.length());
	    	System.out.println("jsonContent: " + jsonContent.toString());
	    	System.out.println("jsonArray: " + vertices);
	    	
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }

    
    
    
    
    /*
     * current sample code from Bluemix Graph Store group.
     * currently failing with a 500 error
     * method takes output previously saved to disk and puts it into a designated graph store
     */
    private void doUpload()
    {
        try
        {
            // String iotype = "graphml"; // graphson or grapmml
            String iotype = "graphson";
            String fieldName, contentType, fileName;
            if (iotype.equals("graphml")) {
                fieldName = "graphml";
                contentType = "application/xml";
                fileName = "graph-of-the-gods-tp3.graphml";
            }
            else {
                fieldName = "graphson";
                contentType = "application/json";
                fileName = outputName;
                ///fileName = "/Users/shirleybraley/dev/bluemix/tabToGraph/workspace/graph-of-the-gods-tp3.graphson";
            }
            
            Long start = System.currentTimeMillis();

            // upload a GraphSON file
            HttpPost httpPost = new HttpPost(apiURL + "/bulkload/" + iotype);
            byte[] userpass = (userId + ":" + password).getBytes();
            byte[] encoding = Base64.encodeBase64(userpass);
            httpPost.setHeader("Authorization", "Basic " + new String(encoding));

            MultipartEntityBuilder meb = MultipartEntityBuilder.create();
            meb.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            meb.addPart("fieldName", new StringBody(fieldName));
            meb.addPart("contentType", new StringBody(contentType));
            meb.addPart("name", new StringBody(fileName));
            //FileBody fileBody = new FileBody(new File("./data/" + fileName));
            FileBody fileBody = new FileBody(new File(fileName));
            meb.addPart(fieldName, fileBody);

            httpPost.setEntity(meb.build());

            HttpResponse httpResponse = client.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();

            // EntityUtils.consume(httpEntity);
            String responseString = EntityUtils.toString(httpEntity, "UTF-8");
            System.out.println(responseString);
            System.out.println("***Ingest time: " + (System.currentTimeMillis() - start)/1000);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
   

}
